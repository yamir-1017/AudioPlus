from django.contrib import admin
from .models import Persona, Producto, Historia, Sintoma, Carrito, Cita,AgendaDia


class personaAdmin(admin.ModelAdmin):

    list_filter = (
        'cc',

    )

    list_display = (
        'nombre',
    )

    search_fields = (
        'cc',
    )


admin.site.register(Persona, personaAdmin)


class productoAdmin(admin.ModelAdmin):

    list_filter = (
        'precio',
    )

    list_display = (
        'nombre',
        'descripcion',
        'precio',
    )

    search_fields = (
        'nombre',
    )


admin.site.register(Producto, productoAdmin)


class historiaAdmin(admin.ModelAdmin):

    list_filter = (
        'paciente',
        'fecha_consulta',
        'hora_consulta',
    )

    list_display = (
        'paciente',
        'fecha_consulta',
        'hora_consulta',
    )

    search_fields = (
        'paciente',
    )


admin.site.register(Historia, historiaAdmin)


class sintomaAdmin(admin.ModelAdmin):

    list_filter = (
        'nombre',
    )

    list_display = (
        'nombre',
        'caracteristicas',
    )

    search_fields = (
        'nombre',
    )


admin.site.register(Sintoma, sintomaAdmin)

  
admin.site.register(AgendaDia)



