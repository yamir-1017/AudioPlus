from django.db import models

ESCOLARIDAD_CHOICES = (
    ("1", "Ninguna"),
    ("2", "Primaria"),
    ("3", "Secundaria"),
    ("4", "Pregrado"),
    ("5", "Posgrado"),
)


class Persona(models.Model):

    cc = models.CharField(max_length=20,primary_key=True,default="")
    fecha_de_nacimiento = models.DateField()
    telefono = models.PositiveIntegerField(unique=True)
    nombre = models.CharField(max_length=20,default="")
    passwd = models.CharField(max_length=20,default="")
    Escolaridad = models.CharField(
        max_length=2,
        choices=ESCOLARIDAD_CHOICES,
        default='1'
    )

    def __str__(self):
        return "{0}".format(self.nombre)

    class Meta:
        verbose_name = "Paciente"
        verbose_name_plural = "Pacientes"


class Producto(models.Model):
    nombre = models.CharField(max_length=40)
    descripcion = models.TextField()
    foto = models.URLField()
    precio = models.FloatField()

    def __str__(self):
        return "{0}".format(self.nombre)

    class Meta:
        verbose_name = "Producto"
        verbose_name_plural = "Productos"

class CalificacionYComentario(models.Model):
    producto = models.ForeignKey(Producto,on_delete=models.CASCADE)
    comentario = models.CharField(max_length=200)
    calificacion = models.IntegerField()

class Sintoma(models.Model):
    nombre = models.CharField(max_length=50)
    caracteristicas = models.TextField()

    def __str__(self):
        return "{0}".format(self.nombre)

    class Meta:
        verbose_name = "Sintoma"
        verbose_name_plural = "Sintomas"


class Historia(models.Model):
    fecha_consulta = models.DateField(auto_now=True, auto_now_add=False)
    hora_consulta = models.TimeField(auto_now=True, auto_now_add=False)
    paciente = models.ForeignKey(
        Persona, null=False, blank=False, on_delete=models.CASCADE)
    sintomas = models.ManyToManyField(Sintoma)
    observaciones = models.TextField()

    def __str__(self):
        return "{0} , {1}".format(self.fecha_consulta, self.hora_consulta)

    class Meta:
        verbose_name = "Historia"
        verbose_name_plural = "Historias"


class Carrito(models.Model):
    paciente = models.ForeignKey(
        Persona, null=False, blank=False, on_delete=models.CASCADE)
    producto = models.ForeignKey(
        Producto, null=False, blank=False, on_delete=models.CASCADE) 

    def __str__(self):
        return "{0}".format(self.paciente)

    class Meta:
        verbose_name = "Factura"
        verbose_name_plural = "Facturas"

def generarAgenda(self):
        for x in range(8):
            minutos= 30*(x%2)
            hora=10+x
            c = Cita(paciente=None,fecha=self,hora=str(hora)+":"+str(minutos)+":00")
            c.save()
class AgendaDia(models.Model):
    dia = models.DateField()
 
    def save(self):
        super(AgendaDia, self).save()
        generarAgenda(self)

    def __str__(self):
        return "{0}".format(self.dia)

class Cita(models.Model):
    paciente = models.ForeignKey(
        Persona, null=True, blank=False, on_delete=models.CASCADE)
    fecha = models.ForeignKey(AgendaDia, on_delete=models.CASCADE)
    hora = models.TimeField()

    def __str__(self):
        return "{0}, {1}".format(self.fecha, self.hora)


