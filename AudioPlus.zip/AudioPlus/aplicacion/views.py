from rest_framework.viewsets import ModelViewSet
from .models import Persona, Producto, Historia, Sintoma, Carrito, Cita, AgendaDia, CalificacionYComentario
from .serializers import PersonaSerializer, AgendaDiaSerializer, ProductoSerializer, HistoriaSerializer, CalificacionSerializer, SintomaSerializer, CarritoSerializer, CitaSerializer
from rest_framework import filters
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from rest_framework.parsers import JSONParser
from random import randint
import nexmo
from datetime import date, timedelta
from rest_framework.response import Response
from rest_framework.decorators import api_view


class PersonaViewSet(ModelViewSet):
    queryset = Persona.objects.all()
    serializer_class = PersonaSerializer


class ProductoViewSet(ModelViewSet):
    queryset = Producto.objects.all()
    serializer_class = ProductoSerializer


class HistoriaViewSet(ModelViewSet):
    queryset = Historia.objects.all()
    serializer_class = HistoriaSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['paciente']
    ordering_fields = ['fecha_consulta']


class SintomaViewSet(ModelViewSet):
    queryset = Sintoma.objects.all()
    serializer_class = SintomaSerializer


class CarritoViewSet(ModelViewSet):
    queryset = Carrito.objects.all()
    serializer_class = CarritoSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['paciente']
    ordering_fields = ['producto']


class CitaViewSet(ModelViewSet):
    queryset = Cita.objects.all()
    serializer_class = CitaSerializer


class CalificacionViewSet(ModelViewSet):
    queryset = CalificacionYComentario.objects.all()
    serializer_class = CalificacionSerializer


class AgendaDiaViewSet(ModelViewSet):
    queryset = AgendaDia.objects.all()
    serializer_class = AgendaDiaSerializer

def sendMessage(message, cel):
    client = nexmo.Client(key='5c2d91d8', secret='LMt06FVWx7np6SBW')
    client.send_message({
        'from': 'Enterprise',
        'to': '57'+str(cel),
        'text': message,
    })

@csrf_exempt
def code(request):
    if request.method == 'POST':

        data = JSONParser().parse(request)
        serializer = PersonaSerializer(data=data)
        if serializer.is_valid():

            code = str(randint(0, 9))+str(randint(0, 9)) + \
                str(randint(0, 9))+str(randint(0, 9))
            sendMessage("Codigo de verificacion:"+code,data['telefono'])
            print(code)
            response = {'code': code}
            return JsonResponse(response, safe=False, status=200)

        response = {'code': "error", 'message': str(serializer.errors)}
        return JsonResponse(response, safe=False, status=400)


@csrf_exempt
def sigin(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        serializer = PersonaSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            response = {'code': "Exito"}
            return JsonResponse(response, safe=False, status=200)
        response = {'code': "error"}
        return JsonResponse(response, safe=False, status=400)


@csrf_exempt
def login(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        print(data)
        queryset = Persona.objects.all()
        if queryset.get(cc=data['cc'], passwd=data['passwd']):

            response = {
                'code': "ok", 'cc': data['cc'], 'pwd': data['passwd'], 'name': "", 'tel': ""}
            return JsonResponse(response, safe=False, status=200)
        response = {'code': "error"}
        return JsonResponse(response, safe=False, status=400)


@csrf_exempt
def comentarios(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        queryset = CalificacionYComentario.objects.all()
        queryset= queryset.filter(producto=data['producto_id'])
        response = CalificacionSerializer(queryset, many=True)
        return JsonResponse(response.data, safe=False, status=200)

@csrf_exempt
def carrito(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        queryset = Carrito.objects.all() 
        queryset= queryset.filter(paciente=data['persona_id']) 
        productos=[]
        total=0
        for x in queryset:
            producto=Producto.objects.get(id=x.producto_id)
            productos.append(producto)
            total+=producto.precio
        response = ProductoSerializer(productos, many=True)
        respons={
            'data':response.data,
            'total':total
        }
        return JsonResponse(respons, safe=False, status=200)



def citas(request):
    if request.method == 'GET':
        dias = []
        for i in range(5):
            dia = date.today() + timedelta(days=i)
            queryset = Cita.objects.filter(fecha__dia=dia.strftime("%Y-%m-%d"))
            serializer = CitaSerializer(queryset, many=True)
            dias.append({'dia': dia.strftime("%Y-%m-%d"),
                         'citas': serializer.data})
        response = {
            'dias':  dias
        }
        return JsonResponse(dias, safe=False)


@csrf_exempt
def cita(request):
    if request.method == 'POST':
        data = JSONParser().parse(request)
        cita = Cita.objects.get(id=data['cita_id'])
        persona =Persona.objects.get(cc=data['paciente_id'])
        cita.paciente = persona
        print(persona.telefono)
        sendMessage("Cita a las:"+str(cita.hora)+" del dia:"+str(cita.fecha)+" a sido confirmada",persona.telefono)
        cita.save()
        response = {
            'code': "ok"
        }
        return JsonResponse(response, safe=False)



