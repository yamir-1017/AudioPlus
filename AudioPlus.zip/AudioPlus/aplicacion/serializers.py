from .models import Persona, Producto, Historia, Sintoma, Carrito, Cita, AgendaDia, CalificacionYComentario, ESCOLARIDAD_CHOICES
from rest_framework import serializers


class PersonaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Persona
        # fields = [attrib, attrib]
        fields = '__all__'


class ProductoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Producto
        # fields = [attrib, attrib]
        fields = '__all__'


class HistoriaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Historia
        # fields = [attrib, attrib]
        fields = '__all__'


class SintomaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sintoma
        # fields = [attrib, attrib]
        fields = '__all__'


class CarritoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Carrito
        # fields = [attrib, attrib]
        fields = '__all__'


class CitaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cita
        # fields = [attrib, attrib]
        fields = '__all__'


class CalificacionSerializer(serializers.ModelSerializer):
    class Meta:
        model = CalificacionYComentario
        fields = '__all__'


class AgendaDiaSerializer(serializers.ModelSerializer):
    class Meta:
        model = AgendaDia
        # fields = [attrib, attrib]
        fields = '__all__'
