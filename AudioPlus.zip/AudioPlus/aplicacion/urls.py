from django.urls import path
from aplicacion import views

urlpatterns = [
    path('signin/', views.sigin),
    path('login/', views.login), 
    path('comentario/', views.comentarios),
    path('citas/', views.citas),
    path('cita/', views.cita),
     path('code/', views.code),
       path('carrito/', views.carrito),

]
